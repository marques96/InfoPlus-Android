package br.com.infoplus.infoplus.features.map.components

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import androidx.annotation.DrawableRes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.graphics.createBitmap
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import br.com.infoplus.infoplus.R
import br.com.infoplus.infoplus.features.map.model.MapMarkerUi
import br.com.infoplus.infoplus.features.map.model.MapZoneUi
import br.com.infoplus.infoplus.features.map.model.ZoneType
import br.com.infoplus.infoplus.features.report.model.OccurrenceCategory
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.model.BitmapDescriptor
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.Circle
import com.google.android.gms.maps.model.CircleOptions
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions

@SuppressLint("MissingPermission")
@Composable
fun MapContainer(
    markers: List<MapMarkerUi>,
    zones: List<MapZoneUi>,
    currentLocation: LatLng?,
    cameraTarget: LatLng?,
    hasLocationPermission: Boolean,
    followUser: Boolean,
    userBearing: Float = 0f,
    onMarkerClick: (MapMarkerUi) -> Unit,
    onUserMoveMap: () -> Unit,
    onCameraIdle: (LatLng) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val mapView = remember {
        MapView(context).apply {
            layoutParams = android.view.ViewGroup.LayoutParams(MATCH_PARENT, MATCH_PARENT)
        }
    }

    var googleMap by remember { mutableStateOf<GoogleMap?>(null) }
    var userMarker by remember { mutableStateOf<Marker?>(null) }
    var userMarkerIcon by remember { mutableStateOf<BitmapDescriptor?>(null) }
    var lastCameraPosition by remember { mutableStateOf<LatLng?>(null) }
    var lastUserMarkerPosition by remember { mutableStateOf<LatLng?>(null) }
    var renderedMarkersVersion by remember { mutableIntStateOf(0) }

    val renderedIncidentMarkers = remember { mutableListOf<Marker>() }
    val renderedZoneCircles = remember { mutableListOf<Circle>() }

    DisposableEffect(lifecycleOwner, mapView) {
        val observer = object : DefaultLifecycleObserver {
            override fun onCreate(owner: LifecycleOwner) {
                mapView.onCreate(null)
            }

            override fun onStart(owner: LifecycleOwner) {
                mapView.onStart()
            }

            override fun onResume(owner: LifecycleOwner) {
                mapView.onResume()
            }

            override fun onPause(owner: LifecycleOwner) {
                mapView.onPause()
            }

            override fun onStop(owner: LifecycleOwner) {
                mapView.onStop()
            }

            override fun onDestroy(owner: LifecycleOwner) {
                mapView.onDestroy()
            }
        }

        lifecycleOwner.lifecycle.addObserver(observer)

        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    LaunchedEffect(Unit) {
        mapView.getMapAsync { map ->
            googleMap = map

            // IMPORTANTE:
            // Só cria o BitmapDescriptor depois que o Maps estiver inicializado.
            userMarkerIcon = createBitmapDescriptorFromVector(
                context = context,
                drawableRes = R.drawable.ic_user_navigation
            )

            map.uiSettings.isZoomControlsEnabled = false
            map.uiSettings.isCompassEnabled = true
            map.uiSettings.isMyLocationButtonEnabled = false
            map.isBuildingsEnabled = true

            // Desativamos o ponto azul padrão porque usaremos marcador próprio.
            map.isMyLocationEnabled = false

            val initialLatLng = currentLocation ?: LatLng(-3.1190, -60.0217)
            val initialZoom = if (currentLocation != null) 16f else 12f

            map.moveCamera(
                CameraUpdateFactory.newLatLngZoom(initialLatLng, initialZoom)
            )

            onCameraIdle(initialLatLng)

            map.setOnMarkerClickListener { clicked ->
                val marker = clicked.tag as? MapMarkerUi
                marker?.let(onMarkerClick)
                marker != null
            }

            map.setOnCameraMoveStartedListener { reason ->
                if (reason == GoogleMap.OnCameraMoveStartedListener.REASON_GESTURE) {
                    onUserMoveMap()
                }
            }

            map.setOnCameraIdleListener {
                onCameraIdle(map.cameraPosition.target)
            }
        }
    }

    LaunchedEffect(markers, zones, googleMap) {
        val map = googleMap ?: return@LaunchedEffect

        renderedIncidentMarkers.forEach { it.remove() }
        renderedIncidentMarkers.clear()

        renderedZoneCircles.forEach { it.remove() }
        renderedZoneCircles.clear()

        zones.forEach { zone ->
            val fillColor = when (zone.type) {
                ZoneType.RISK -> android.graphics.Color.argb(70, 239, 83, 80)
                ZoneType.FRIENDLY -> android.graphics.Color.argb(55, 76, 175, 80)
            }

            val strokeColor = when (zone.type) {
                ZoneType.RISK -> android.graphics.Color.argb(180, 198, 40, 40)
                ZoneType.FRIENDLY -> android.graphics.Color.argb(170, 46, 125, 50)
            }

            val circle = map.addCircle(
                CircleOptions()
                    .center(LatLng(zone.centerLat, zone.centerLon))
                    .radius(zone.radiusMeters)
                    .fillColor(fillColor)
                    .strokeColor(strokeColor)
                    .strokeWidth(3f)
                    .zIndex(1f)
            )

            renderedZoneCircles += circle
        }

        markers.forEach { marker ->
            val hue = when (marker.category) {
                OccurrenceCategory.ASSALTO,
                OccurrenceCategory.VIOLENCIA,
                OccurrenceCategory.DESAPARECIMENTO -> BitmapDescriptorFactory.HUE_RED

                OccurrenceCategory.ASSEDIO -> BitmapDescriptorFactory.HUE_VIOLET
                OccurrenceCategory.EMERGENCIA_MEDICA -> BitmapDescriptorFactory.HUE_ORANGE
                OccurrenceCategory.OUTROS,
                null -> BitmapDescriptorFactory.HUE_AZURE
            }

            val googleMarker = map.addMarker(
                MarkerOptions()
                    .position(LatLng(marker.lat, marker.lon))
                    .title(marker.title)
                    .snippet(marker.snippet)
                    .icon(BitmapDescriptorFactory.defaultMarker(hue))
                    .zIndex(2f)
            )

            googleMarker?.tag = marker
            googleMarker?.let { renderedIncidentMarkers += it }
        }

        renderedMarkersVersion++
    }

    LaunchedEffect(
        currentLocation,
        userBearing,
        googleMap,
        hasLocationPermission,
        userMarkerIcon,
        renderedMarkersVersion
    ) {
        val map = googleMap ?: return@LaunchedEffect

        if (!hasLocationPermission || currentLocation == null) {
            userMarker?.remove()
            userMarker = null
            lastUserMarkerPosition = null
            return@LaunchedEffect
        }

        val safeBearing = userBearing.normalizeBearing()

        val existingMarker = userMarker
        if (existingMarker == null) {
            val markerOptions = MarkerOptions()
                .position(currentLocation)
                .anchor(0.5f, 0.5f)
                .flat(true)
                .rotation((safeBearing + 180f) % 360f)
                .zIndex(10f)

            userMarkerIcon?.let { markerOptions.icon(it) }

            userMarker = map.addMarker(markerOptions)
            lastUserMarkerPosition = currentLocation
            return@LaunchedEffect
        }

        val shouldMoveMarker = lastUserMarkerPosition == null ||
                distanceBetween(lastUserMarkerPosition!!, currentLocation) > 1.5f

        if (shouldMoveMarker) {
            existingMarker.position = currentLocation
            lastUserMarkerPosition = currentLocation
        }

        existingMarker.rotation = safeBearing
        existingMarker.isFlat = true
        existingMarker.zIndex = 10f
    }

    LaunchedEffect(cameraTarget, googleMap, followUser) {
        val map = googleMap ?: return@LaunchedEffect
        val target = cameraTarget ?: return@LaunchedEffect

        val shouldForceMove = followUser
        val last = lastCameraPosition
        val shouldMove = shouldForceMove || last == null || distanceBetween(last, target) > 5f

        if (!shouldMove) return@LaunchedEffect

        lastCameraPosition = target

        map.animateCamera(
            CameraUpdateFactory.newLatLngZoom(target, if (followUser) 17f else 16f)
        )
    }

    AndroidView(
        factory = { mapView }
    )
}

private fun distanceBetween(a: LatLng, b: LatLng): Float {
    val result = FloatArray(1)
    android.location.Location.distanceBetween(
        a.latitude, a.longitude,
        b.latitude, b.longitude,
        result
    )
    return result[0]
}

private fun Float.normalizeBearing(): Float {
    var value = this % 360f
    if (value < 0f) value += 360f
    return value
}

private fun createBitmapDescriptorFromVector(
    context: Context,
    @DrawableRes drawableRes: Int
): BitmapDescriptor? {
    return try {
        val drawable = ContextCompat.getDrawable(context, drawableRes) ?: return null
        drawable.toBitmapDescriptorOrNull()
    } catch (_: Exception) {
        null
    }
}

private fun Drawable.toBitmapDescriptorOrNull(): BitmapDescriptor? {
    return try {
        val width = intrinsicWidth.takeIf { it > 0 } ?: 96
        val height = intrinsicHeight.takeIf { it > 0 } ?: 96

        val bitmap: Bitmap = createBitmap(width, height)
        val canvas = Canvas(bitmap)
        setBounds(0, 0, canvas.width, canvas.height)
        draw(canvas)

        BitmapDescriptorFactory.fromBitmap(bitmap)
    } catch (_: Exception) {
        null
    }
}